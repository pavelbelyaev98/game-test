using UnityEngine;

namespace SomethingDownThere
{
    // World-space growth, shared numerically with SurfaceVegetation.hlsl. This
    // selects between the approved soil/turf art; it has no camera or save state.
    public static class SurfaceVegetation
    {
        public static float Growth(Vector2 world)
        {
            return Noise(world * .19f) * .68f
                + Noise(world * .43f + new Vector2(17.3f, -9.2f)) * .22f
                + Noise(world * .91f + new Vector2(-4.7f, 23.1f)) * .1f;
        }

        public static float Coverage(Vector2 world) => Smooth(.42f, .54f, Growth(world));
        public static float Smooth(float low, float high, float value)
        {
            float t = Mathf.Clamp01((value - low) / (high - low));
            return t * t * (3 - 2 * t);
        }

        private static float Noise(Vector2 p)
        {
            int x = Mathf.FloorToInt(p.x), z = Mathf.FloorToInt(p.y);
            float u = p.x - x, v = p.y - z;
            u = u * u * (3 - 2 * u); v = v * v * (3 - 2 * v);
            return Mathf.Lerp(Mathf.Lerp(Hash(x, z), Hash(x + 1, z), u),
                Mathf.Lerp(Hash(x, z + 1), Hash(x + 1, z + 1), u), v);
        }

        private static float Hash(int x, int z)
        {
            unchecked
            {
                uint h = (uint)x * 374761393u + (uint)z * 668265263u + 133u * 1442695041u;
                h = (h ^ (h >> 13)) * 1274126177u;
                return ((h ^ (h >> 16)) & 0x00ffffffu) / 16777215f;
            }
        }
    }
}
