#ifndef SOMETHING_DOWN_THERE_SURFACE_VEGETATION
#define SOMETHING_DOWN_THERE_SURFACE_VEGETATION
// Keep the integer hash, scales and thresholds aligned with SurfaceVegetation.cs.
float VegetationHash(int2 cell)
{
    uint h = (uint)cell.x * 374761393u + (uint)cell.y * 668265263u + 133u * 1442695041u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return ((h ^ (h >> 16)) & 0x00ffffffu) / 16777215.0;
}
float VegetationNoise(float2 p)
{
    int2 cell = (int2)floor(p);
    float2 f = frac(p); f = f * f * (3 - 2 * f);
    return lerp(lerp(VegetationHash(cell),VegetationHash(cell+int2(1,0)),f.x),
        lerp(VegetationHash(cell+int2(0,1)),VegetationHash(cell+int2(1,1)),f.x),f.y);
}
float VegetationCoverage(float2 world)
{
    float growth = VegetationNoise(world*.19)*.68
        + VegetationNoise(world*.43+float2(17.3,-9.2))*.22
        + VegetationNoise(world*.91+float2(-4.7,23.1))*.1;
    return smoothstep(.42,.54,growth);
}
#endif
