# Sunny surface grass

Approved by the user on 2026-09-12 for [127](../../docs/development/tasks/127-moving-grass-and-shovel-strength.md), and refined in place at their explicit request in [129](../../docs/development/tasks/129-grass-shape-and-wind.md).

- `GroundGrass.blend`: editable Blender grass and preview scene. The 12-blade clump remains 168 triangles, with 26–42 cm authored heights (20–44 cm after seeded game scaling). The unused six-blade mesh remains 84 triangles. Hidden source clumps are retained beside linked review instances.
- `refine_grass.py` reproduces the current mesh, atlas and preview from the existing source. `create_grass.py` builds the original foundation in a fresh file; follow it with `refine_grass.py` for the current revision. Set `__file__` to each recipe's absolute path when executing through Blender MCP. Both preserve unrelated scenes; the refinement preserves topology, object names and blade-root centres.
- `GrassClumps.fbx`: both upright metre-scale meshes. UV0 samples the atlas and supplies rooted bend weights; UV1 retains each blade's phase and height. `Grass_Albedo.png`: 128×256 Blender-baked root/tip gradient with restrained blade-to-blade greens. The softened fold and two-sided diffuse lighting preserve broad matte leaf shapes.
- `preview.png` shows the current Blender source. [MainGame comparisons and wind video](../../docs/development/grass-review-129/index.html) show actual game presentation.
- Runtime: `Assets/Content/GroundGrass/`; run **Configure Approved Surface Grass** in MainGame to refresh references/import settings without replacing existing GUIDs.
- Grass grows only on the original upper excavation surface. A conservative root footprint clears near unsupported lips; it does not grow on excavated walls or underground floors.
- Travelling gusts bend the upper blade, with varied tip response and matching bent normals. Roots stay fixed. Task 128's full twelve-blade density remains throughout the visible site; spatial culling includes tall tips and the wind envelope. Blades receive sunlight/shadows and fog; they do not add shadow-caster passes.
- `previous-approved.zip` retains the source/runtime files and affected tests before 129, at repository-relative paths. Restore those listed paths, remove `refine_grass.py`, reimport through the Editor and run Configure Approved Surface Grass to revert this refinement. The ledger owns full removal; keep the independent sun, ground and shovel changes.

Full source/runtime ownership and removal: [asset ledger](../../docs/asset-ledger.md). Keep existing ground assets and saved terrain during removal.
