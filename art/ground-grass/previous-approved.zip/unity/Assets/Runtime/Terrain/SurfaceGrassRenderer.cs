using System;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.Rendering;

namespace SomethingDownThere
{
    // Authored clumps, instanced in small spatial batches. Grass is derived from
    // the original surface and current soil; no grass state belongs in a save.
    [DisallowMultipleComponent, RequireComponent(typeof(TerrainVolume))]
    public sealed class SurfaceGrassRenderer : MonoBehaviour
    {
        [SerializeField] private Mesh nearMesh;
        [SerializeField] private Material material;
        [SerializeField, Min(1)] private float patchSize = 2f;
        [SerializeField, Range(4, 20)] private int cellsPerPatch = 12;
        private const int Seed = 127;
        private sealed class Patch
        {
            public Bounds Bounds;
            public Vector3[] Roots;
            public Matrix4x4[] Candidates, Near;
            public int NearCount;
            public bool Dirty = true;
        }
        private TerrainVolume terrain;
        private readonly List<Patch> patches = new List<Patch>();
        private readonly Plane[] planes = new Plane[6];
        public int PatchCount => patches.Count;
        public int SupportedClumps { get; private set; }
        public int LastRebuiltPatches { get; private set; }
        public double LastRebuildMilliseconds { get; private set; }
        public double LastSubmissionMilliseconds { get; private set; }
        public int LastDrawCalls { get; private set; }
        public int LastTriangles { get; private set; }
        public int LastVisibleClumps { get; private set; }
        public ulong PlacementHash { get; private set; }

        private void OnEnable()
        {
            terrain = GetComponent<TerrainVolume>();
            terrain.Changed += SoilChanged;
            RenderPipelineManager.beginCameraRendering += RenderCamera;
        }

        private void OnDisable()
        {
            if (terrain != null) terrain.Changed -= SoilChanged;
            RenderPipelineManager.beginCameraRendering -= RenderCamera;
            patches.Clear();
            SupportedClumps = LastRebuiltPatches = LastDrawCalls = LastTriangles = LastVisibleClumps = 0;
            PlacementHash = 0;
        }

        private void LateUpdate()
        {
            LastRebuiltPatches = 0;
            if (terrain == null || !terrain.CanDig || terrain.IsRestoring) return;
            if (nearMesh == null || material == null) return;
            var start = Stopwatch.GetTimestamp();
            if (patches.Count == 0) CreatePatches();
            foreach (var patch in patches)
            {
                if (!patch.Dirty) continue;
                SupportedClumps -= patch.NearCount;
                patch.NearCount = 0;
                for (int i = 0; i < patch.Roots.Length; i++)
                {
                    if (!RootSupported(patch.Roots[i])) continue;
                    patch.Near[patch.NearCount++] = patch.Candidates[i];
                }
                SupportedClumps += patch.NearCount;
                patch.Dirty = false;
                LastRebuiltPatches++;
            }
            if (LastRebuiltPatches > 0) UpdatePlacementHash();
            LastRebuildMilliseconds = (Stopwatch.GetTimestamp() - start) * 1000.0 / Stopwatch.Frequency;
        }

        private void CreatePatches()
        {
            // At most 400 instances per draw, below Unity's conservative 511 limit.
            int cells = Mathf.Clamp(cellsPerPatch, 4, 20);
            float size = Mathf.Max(1, patchSize);
            var extent = (Vector3)terrain.Dimensions * terrain.CellSize;
            var random = new System.Random(Seed);
            for (float z = 0; z < extent.z; z += size)
            for (float x = 0; x < extent.x; x += size)
            {
                var roots = new List<Vector3>(cells * cells);
                var matrices = new List<Matrix4x4>(cells * cells);
                for (int iz = 0; iz < cells; iz++)
                for (int ix = 0; ix < cells; ix++)
                {
                    float px = x + (ix + .5f + ((float)random.NextDouble() - .5f) * .8f) * size / cells;
                    float pz = z + (iz + .5f + ((float)random.NextDouble() - .5f) * .8f) * size / cells;
                    if (px > extent.x - .03f || pz > extent.z - .03f) continue;
                    var root = terrain.transform.TransformPoint(new Vector3(px, extent.y - .006f, pz));
                    float scale = Mathf.Lerp(.75f, 1.05f, (float)random.NextDouble());
                    roots.Add(root);
                    matrices.Add(Matrix4x4.TRS(root, terrain.transform.rotation *
                        Quaternion.Euler(0, (float)random.NextDouble() * 360, 0), Vector3.one * scale));
                    // Consume the former thinning draw so Task 127's seeded
                    // root positions stay identical while rendering full density.
                    random.NextDouble();
                }
                var bounds = new Bounds(terrain.transform.TransformPoint(new Vector3(x, extent.y, z)), Vector3.zero);
                bounds.Encapsulate(terrain.transform.TransformPoint(new Vector3(Mathf.Min(x + size, extent.x), extent.y, z)));
                bounds.Encapsulate(terrain.transform.TransformPoint(new Vector3(x, extent.y, Mathf.Min(z + size, extent.z))));
                bounds.Encapsulate(terrain.transform.TransformPoint(new Vector3(Mathf.Min(x + size, extent.x), extent.y, Mathf.Min(z + size, extent.z))));
                bounds.Expand(.7f); // Includes authored blades and maximum wind displacement.
                patches.Add(new Patch { Bounds = bounds, Roots = roots.ToArray(), Candidates = matrices.ToArray(),
                    Near = new Matrix4x4[roots.Count] });
            }
        }

        private bool RootSupported(Vector3 root)
        {
            // Test the clump footprint at the original turf, not a lower wall or
            // nearby floor. A conservative skirt prevents roots hovering at lips.
            Vector3 down = -terrain.transform.up * .018f;
            Vector3 a = terrain.transform.right * .085f, b = terrain.transform.forward * .085f;
            return terrain.IsSolid(root + down) && terrain.IsSolid(root + down + a)
                && terrain.IsSolid(root + down - a) && terrain.IsSolid(root + down + b)
                && terrain.IsSolid(root + down - b);
        }

        private void SoilChanged(Bounds changed)
        {
            changed.Expand(.25f);
            foreach (var patch in patches)
                if (patch.Bounds.Intersects(changed)) patch.Dirty = true;
        }

        private void UpdatePlacementHash()
        {
            ulong hash = 14695981039346656037UL;
            foreach (var patch in patches)
            for (int i = 0; i < patch.NearCount; i++)
            {
                Vector4 p = patch.Near[i].GetColumn(3);
                unchecked
                {
                    hash = (hash ^ (uint)Mathf.RoundToInt(p.x * 10000)) * 1099511628211UL;
                    hash = (hash ^ (uint)Mathf.RoundToInt(p.z * 10000)) * 1099511628211UL;
                }
            }
            PlacementHash = hash;
        }

        private void RenderCamera(ScriptableRenderContext context, Camera camera)
        {
            if (camera.cameraType != CameraType.Game && camera.cameraType != CameraType.SceneView) return;
            LastDrawCalls = LastTriangles = LastVisibleClumps = 0;
            if (terrain == null || terrain.IsRestoring || patches.Count == 0 || !SystemInfo.supportsInstancing) return;
            var start = Stopwatch.GetTimestamp();
            GeometryUtility.CalculateFrustumPlanes(camera, planes);
            foreach (var patch in patches)
            {
                if (patch.NearCount == 0 || !GeometryUtility.TestPlanesAABB(planes, patch.Bounds)) continue;
                // The site is small. Keep every supported blade at all visible
                // distances; switching density made patches visibly grow on approach.
                int count = patch.NearCount;
                var parameters = new RenderParams(material) {
                    camera = camera, worldBounds = patch.Bounds, layer = gameObject.layer,
                    shadowCastingMode = ShadowCastingMode.Off, receiveShadows = true,
                    lightProbeUsage = LightProbeUsage.Off, motionVectorMode = MotionVectorGenerationMode.Camera
                };
                Graphics.RenderMeshInstanced(parameters, nearMesh, 0, patch.Near, count);
                LastDrawCalls++;
                LastVisibleClumps += count;
                LastTriangles += count * (int)(nearMesh.GetIndexCount(0) / 3);
            }
            LastSubmissionMilliseconds = (Stopwatch.GetTimestamp() - start) * 1000.0 / Stopwatch.Frequency;
        }
    }
}
