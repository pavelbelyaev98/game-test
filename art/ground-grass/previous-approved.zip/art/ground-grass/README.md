# Sunny surface grass

Approved by the user on 2026-09-12 for [127](../../docs/development/tasks/127-moving-grass-and-shovel-strength.md).

- `GroundGrass.blend`: editable Blender grass and preview scene. The 12-blade clump is 168 triangles; the six-blade distance mesh is 84. Hidden source clumps are retained beside linked review instances.
- `create_grass.py`: Blender MCP recipe; run in a fresh file. Set `__file__` to this recipe's absolute path when executing its text through MCP. It creates its own review scene, preserving unrelated content; it refuses duplicate grass names. Export edits directly from the retained blend when refining that source.
- `GrassClumps.fbx`: both upright metre-scale meshes, UVs and root-to-tip vertex weights. `Grass_Albedo.png`: 128×256 Blender-baked root/tip gradient. Uniform matte roughness is authored in the Blender source and translated into the diffuse runtime material.
- `preview.png` is the approved Blender batch review, not evidence of in-game lighting/performance.
- Runtime: `Assets/Content/GroundGrass/`; run **Configure Approved Surface Grass** in MainGame to refresh references/import settings without replacing existing GUIDs.
- Grass grows only on the original upper excavation surface. A conservative root footprint clears near unsupported lips; it does not grow on excavated walls or underground floors.
- Gentle vertex sway holds the roots fixed. Task 128 keeps the full twelve-blade clump density throughout the visible site, with spatial view culling. The unused six-blade mesh remains in the approved source/export. Blades receive sunlight/shadows and fog; they do not add shadow-caster passes.

Full source/runtime ownership and removal: [asset ledger](../../docs/asset-ledger.md). Keep existing ground assets and saved terrain during removal.
