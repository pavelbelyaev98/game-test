Shader "Something Down There/Sunny Cloud Sky"
{
    Properties
    {
        _SunMap("Approved sun", 2D) = "black" {}
        _SkyColor("Existing blue sky", Color) = (.48,.67,.79,1)
        _SunDirection("Direction toward sun", Vector) = (0,1,0,0)
        _SunTangentRadius("Sun texture tangent half-width", Float) = .08749
        _CloudMap("Blender cloud atlas", 2D) = "black" {}
        _CloudScale("Cloud size", Float) = 1
        _CloudSpeed("Cloud drift", Float) = .003
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" }
        Cull Off ZWrite Off
        Pass
        {
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma target 3.0
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            TEXTURE2D(_SunMap); SAMPLER(sampler_SunMap);
            TEXTURE2D(_CloudMap); SAMPLER(sampler_CloudMap);
            CBUFFER_START(UnityPerMaterial)
            half4 _SkyColor;
            float4 _SunDirection;
            float _SunTangentRadius, _CloudScale, _CloudSpeed;
            CBUFFER_END
            struct Attributes { float4 positionOS : POSITION; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varyings { float4 positionCS : SV_POSITION; float3 direction : TEXCOORD0; UNITY_VERTEX_OUTPUT_STEREO };
            Varyings Vert(Attributes input)
            {
                UNITY_SETUP_INSTANCE_ID(input);
                Varyings output;
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.direction = input.positionOS.xyz;
                return output;
            }
            float Hash(float2 cell) { return frac(sin(dot(cell,float2(127.1,311.7))) * 43758.5453); }
            half4 Frag(Varyings input) : SV_Target
            {
                float3 view = normalize(input.direction);
                float3 sun = normalize(_SunDirection.xyz);
                half3 sky = _SkyColor.rgb;
                float forward = dot(view,sun);
                float3 axis = abs(sun.y) < .99 ? float3(0,1,0) : float3(0,0,1);
                float3 right = normalize(cross(axis,sun));
                float3 up = cross(sun,right);
                float2 sunUv = float2(dot(view,right),dot(view,up)) /
                    (max(forward,.0001) * max(_SunTangentRadius,.001) * 2) + .5;
                if (forward > 0 && all(sunUv >= 0) && all(sunUv <= 1)) {
                    half4 disc = SAMPLE_TEXTURE2D(_SunMap,sampler_SunMap,sunUv);
                    sky = lerp(sky,disc.rgb,disc.a);
                }
                if (view.y <= .07) return half4(sky,1);
                // A finite set of upright authored silhouettes on the sky dome:
                // no horizon tile repetition, camera parallax or wrap seams.
                [unroll] for (int i = 0; i < 14; i++) {
                    float yaw = i * 2.399963 + _Time.y * _CloudSpeed;
                    float elevation = .23 + Hash(float2(i,7.1)) * .88;
                    float3 facing = float3(sin(yaw)*cos(elevation),sin(elevation),cos(yaw)*cos(elevation));
                    float depth = dot(view,facing);
                    float3 horizontal = float3(cos(yaw),0,-sin(yaw));
                    float3 vertical = cross(facing,horizontal);
                    float width = (.28 + Hash(float2(i,13.7))*.14) * _CloudScale;
                    float2 uv = float2(dot(view,horizontal),dot(view,vertical)) / (max(depth,.001)*width*2) + .5;
                    float2 dx = ddx(uv)*.5, dy = ddy(uv)*.5;
                    if (depth < .82 || any(uv < .005) || any(uv > .995)) continue;
                    float2 tile = float2(i & 1,(i >> 1) & 1);
                    half4 cloud = SAMPLE_TEXTURE2D_GRAD(_CloudMap,sampler_CloudMap,(uv+tile)*.5,dx,dy);
                    half opacity = saturate((cloud.a-.02h)/.98h);
                    sky = lerp(sky,cloud.rgb,opacity * smoothstep(.07,.18,view.y));
                }
                return half4(sky,1);
            }
            ENDHLSL
        }
    }
}
