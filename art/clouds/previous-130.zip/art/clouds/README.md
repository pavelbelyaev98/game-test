# Approved cartoon clouds

The user explicitly approved clouds on 2026-09-12 in task 130.

`Clouds.blend` contains four original soft cloud forms and the atlas camera;
`create_clouds.py` recreates the forms through Blender MCP in an empty owned
authoring scene. `CloudAtlas.png` is the rendered 1024px RGBA 2x2 atlas.
`preview.png` is an authoring review, not a game screenshot. The source includes
the final base/lobe smoothing; rerender the saved scene for pixel-identical art.

The Unity sky material places fourteen softly drifting silhouettes around the
sky, preserving the existing sky color and approved sun. It adds no scene mesh,
collider, lighting change or saved state. Ownership/removal is in
`docs/asset-ledger.md`. Original art; free commercial use and modification,
redistribution and sale without attribution, under `LICENSE.txt`.
