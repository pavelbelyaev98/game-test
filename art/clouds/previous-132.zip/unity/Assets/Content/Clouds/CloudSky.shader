Shader "Something Down There/Sunny Cloud Sky"
{
    Properties
    {
        _SunMap("Approved sun", 2D) = "black" {}
        _SkyColor("Bright cyan sky", Color) = (.12,.77,.85,1)
        _HorizonColor("Light cyan horizon", Color) = (.42,.88,.9,1)
        _SunDirection("Direction toward sun", Vector) = (0,1,0,0)
        _SunTangentRadius("Sun texture tangent half-width", Float) = .08749
        _CloudMap("Blender cloud atlas", 2D) = "black" {}
        _CloudSpeed("Cloud drift radians per second", Float) = .0015
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" }
        Cull Off ZWrite Off
        Pass
        {
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma target 3.0
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            TEXTURE2D(_SunMap); SAMPLER(sampler_SunMap);
            TEXTURE2D(_CloudMap); SAMPLER(sampler_CloudMap);
            CBUFFER_START(UnityPerMaterial)
            float4 _SkyColor, _HorizonColor;
            float4 _SunDirection;
            float _SunTangentRadius, _CloudSpeed;
            CBUFFER_END
            struct Attributes { float4 positionOS : POSITION; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varyings { float4 positionCS : SV_POSITION; float3 direction : TEXCOORD0; UNITY_VERTEX_OUTPUT_STEREO };
            Varyings Vert(Attributes input)
            {
                UNITY_SETUP_INSTANCE_ID(input);
                Varyings output;
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.direction = input.positionOS.xyz;
                return output;
            }
            float4 Frag(Varyings input) : SV_Target
            {
                float3 view = normalize(input.direction);
                float3 sun = normalize(_SunDirection.xyz);
                float3 sky = lerp(_HorizonColor.rgb, _SkyColor.rgb, smoothstep(0, .85, view.y));
                float forward = dot(view,sun);
                float3 axis = abs(sun.y) < .99 ? float3(0,1,0) : float3(0,0,1);
                float3 right = normalize(cross(axis,sun));
                float3 up = cross(sun,right);
                float2 sunUv = float2(dot(view,right),dot(view,up)) /
                    (max(forward,.0001) * max(_SunTangentRadius,.001) * 2) + .5;
                float4 disc = SAMPLE_TEXTURE2D_GRAD(_SunMap,sampler_SunMap,saturate(sunUv),ddx(sunUv),ddy(sunUv));
                float sunCoverage = step(0,forward) * step(0,sunUv.x) * step(sunUv.x,1) * step(0,sunUv.y) * step(sunUv.y,1);
                sky = lerp(sky,disc.rgb,disc.a * sunCoverage);

                // Four deliberate placements, all horizontal in sky longitude/latitude.
                // Their generous separation leaves the upper sky open. No camera position,
                // random rotation, distance culling or card clipping enters this projection.
                static const float4 clouds[4] = {
                    float4(35, 17, 38, 30), float4(125, 23, 34, 28),
                    float4(220, 16, 40, 30), float4(308, 25, 35, 28)
                };
                float longitude = atan2(view.x,view.z) - _Time.y * _CloudSpeed;
                float latitude = asin(clamp(view.y,-1,1));
                float3 dx = ddx(view), dy = ddy(view);
                float horizontalLengthSq = max(dot(view.xz,view.xz),.00001);
                float verticalLength = sqrt(horizontalLengthSq);
                // Analytic gradients stay continuous across longitude's wrap, unlike ddx(atan2).
                float2 angleDx = float2((view.z*dx.x-view.x*dx.z)/horizontalLengthSq, dx.y/verticalLength);
                float2 angleDy = float2((view.z*dy.x-view.x*dy.z)/horizontalLengthSq, dy.y/verticalLength);
                [unroll] for (int i = 0; i < 4; i++) {
                    float4 placement = radians(clouds[i]);
                    float delta = longitude - placement.x;
                    float2 uv = float2(atan2(sin(delta),cos(delta)), latitude-placement.y) / placement.zw + .5;
                    float2 tile = float2(i & 1,(i >> 1) & 1);
                    // Every pixel follows the same full-precision blend path; transparent
                    // cell gutters prevent neighboring tiles bleeding into the sky.
                    float2 atlasUv = (clamp(uv,.01,.99)+tile)*.5;
                    float4 cloud = SAMPLE_TEXTURE2D_GRAD(_CloudMap,sampler_CloudMap,atlasUv,
                        angleDx/placement.zw*.5,angleDy/placement.zw*.5);
                    float opacity = saturate((cloud.a-.015)/.985);
                    opacity *= step(0,uv.x) * step(uv.x,1) * step(0,uv.y) * step(uv.y,1) * smoothstep(.035,.1,view.y);
                    sky = lerp(sky,cloud.rgb,opacity);
                }
                return float4(sky,1);
            }
            ENDHLSL
        }
    }
}
