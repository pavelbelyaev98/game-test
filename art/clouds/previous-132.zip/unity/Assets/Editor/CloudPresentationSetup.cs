using System;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SomethingDownThere.Editor
{
    public static class CloudPresentationSetup
    {
        public const string Folder = "Assets/Content/Clouds/";
        [MenuItem("Tools/Something Down There/Configure Approved Clouds")]
        public static void Configure()
        {
            var scene = SceneManager.GetActiveScene();
            if (EditorApplication.isPlaying || scene.name != "MainGame")
                throw new InvalidOperationException("Open MainGame outside Play Mode.");
            var root = scene.GetRootGameObjects().Single(o => o.name == "MainGameRoot");
            var camera = root.GetComponentInChildren<Camera>();
            var sky = camera.GetComponent<Skybox>();
            var sunMaterial = AssetDatabase.LoadAssetAtPath<Material>(SunPresentationSetup.Folder + "SunnySun.mat");
            if (sky == null || sunMaterial == null)
                throw new InvalidOperationException("Configure the approved sun before the clouds.");
            var importer = AssetImporter.GetAtPath(Folder + "CloudAtlas.png") as TextureImporter;
            if (importer == null) throw new InvalidOperationException("Import the approved Blender clouds first.");
            importer.sRGBTexture = true;
            importer.alphaSource = TextureImporterAlphaSource.FromInput;
            importer.alphaIsTransparency = true;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Trilinear;
            importer.mipmapEnabled = true;
            importer.textureCompression = TextureImporterCompression.CompressedHQ;
            importer.SaveAndReimport();
            var shader = Shader.Find("Something Down There/Sunny Cloud Sky");
            if (shader == null || ShaderUtil.ShaderHasError(shader))
                throw new InvalidOperationException("The cloud sky shader must compile before integration.");
            var material = AssetDatabase.LoadAssetAtPath<Material>(Folder + "CloudSky.mat");
            if (material == null) {
                material = new Material(shader) { name = "CloudSky" };
                AssetDatabase.CreateAsset(material, Folder + "CloudSky.mat");
            }
            Undo.RecordObjects(new UnityEngine.Object[] { material, camera, sky }, "Configure approved clouds");
            material.shader = shader;
            material.SetTexture("_SunMap", sunMaterial.GetTexture("_SunMap"));
            material.SetFloat("_SunTangentRadius", sunMaterial.GetFloat("_SunTangentRadius"));
            camera.backgroundColor = new Color(.12f, .77f, .85f, 1f);
            material.SetColor("_SkyColor", camera.backgroundColor);
            material.SetColor("_HorizonColor", new Color(.42f, .88f, .9f, 1f));
            material.SetVector("_SunDirection", -root.transform.Find("Sun").forward);
            var atlas = AssetDatabase.LoadAssetAtPath<Texture2D>(Folder + "CloudAtlas.png");
            if (atlas == null) throw new InvalidOperationException("The approved cloud atlas did not import.");
            material.SetTexture("_CloudMap", atlas);
            material.SetFloat("_CloudSpeed", .0015f);
            sky.material = material;
            camera.clearFlags = CameraClearFlags.Skybox;
            EditorUtility.SetDirty(material);
            EditorUtility.SetDirty(camera);
            EditorUtility.SetDirty(sky);
            EditorSceneManager.MarkSceneDirty(scene);
            AssetDatabase.SaveAssets();
        }
    }
}
